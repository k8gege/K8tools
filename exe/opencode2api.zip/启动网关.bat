@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================
echo   opencode2api 网关启动中...
echo   API 地址: http://127.0.0.1:8080/v1
echo   WebUI   : http://127.0.0.1:8081
echo ============================================
echo.
opencode2api.exe -config config.json
pause
